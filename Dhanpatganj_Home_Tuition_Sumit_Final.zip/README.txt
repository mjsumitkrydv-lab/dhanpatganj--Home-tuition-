DHANPATGANJ HOME TUITION — WEBSITE

Contact:
Name: Sumit
Phone/WhatsApp: 8090403183
Location: Dhanpatganj
Classes: 9th, 10th, 11th, 12th
Competitive: NDA, Air Force
Offer: Free Demo Class
Positioning: Budget Friendly

The website is already configured with the supplied WhatsApp number.
Open index.html to preview it.

To put it online:
- Use any static website host and upload index.html.
- A custom domain can later be connected, e.g. dhanpatganjhometuition.in (availability must be checked before purchase).
